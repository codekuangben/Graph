//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by test.rc
//
#define IDI_MAIN_ICON                       101
#define IDR_CONTEXT                     102
#define ID_TOGGLE_WIREFRAME             103
#define ID_SHOW_COLORS                  104
#define ID_SHOW_DEPTH                   105
#define ID_SHOW_BLUR                    106
#define ID_ABOUT                        107
#define ID_B                            108
#define ID_CONTEXTMENU_TOGGLEWIREFRAME  109
#define ID_CONTEXTMENU_SHOWCOLORS       110
#define ID_CONTEXTMENU_SHOWDEPTH        111
#define ID_CONTEXTMENU_SHOWBLURRINESS   112
#define ID_CONTEXTMENU_ABOUTDEPTHOFFIELD 113
#define ID_SHOW_HELP                    114
#define ID_FULLSCREEN                   115

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        116
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
